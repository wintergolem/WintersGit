#ifndef _GLSLCOOKBOOK_OGL
#define _GLSLCOOKBOOK_OGL

#include "gl_core_4_3.h"

#endif
